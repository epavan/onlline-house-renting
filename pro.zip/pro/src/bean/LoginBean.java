package bean;

public class LoginBean {
	private String user;
	private String password;
	public LoginBean() {
		// TODO Auto-generated constructor stub
	}
	public LoginBean(String user, String password) {
		super();
		this.user = user;
		this.password = password;
	}
	public String getUser() {
		return user;
	}
	public void setUser(String user) {
		this.user = user;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "LoginBean [user=" + user + ", password=" + password + "]";
	}
	

}
