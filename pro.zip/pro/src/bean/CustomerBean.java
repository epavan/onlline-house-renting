package bean;

public class CustomerBean {
	private String fname;
	private String lname;
	private String age;
	private String gender;
	private String phone;
	private String mail;
	private String password;
	private String address;
	
	public CustomerBean() {
		// TODO Auto-generated constructor stub
	}

	public CustomerBean(String fname, String lname, String age, String gender, String phone, String mail, String password,
			String address) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		this.gender = gender;
		this.phone = phone;
		this.mail = mail;
		this.password = password;
		this.address = address;
	}

	public String getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname = fname;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "CustomerBean [fname=" + fname + ", lname=" + lname + ", age=" + age + ", gender=" + gender + ", phone="
				+ phone + ", mail=" + mail + ", password=" + password + ", address=" + address + "]";
	}
	
	
}
