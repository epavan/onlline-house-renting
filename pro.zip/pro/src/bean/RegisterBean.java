package bean;

public class RegisterBean {
	private String fname;
	private String lname;
	private String age;
	
	private String phone;
	private String mail;
	private String password;
	private String address;
	private String type;
	private String city;
	private String image;
	public RegisterBean() {
		// TODO Auto-generated constructor stub
	}	public RegisterBean(String fname, String lname, String age, String phone, String mail, String password, String address,

			String type,String city, String image) {
		super();
		this.fname = fname;
		this.lname = lname;
		this.age = age;
		this.phone = phone;
		this.mail = mail;
		this.password = password;
		this.address = address;
		this.type = type;
		this.city = city;
		this.image = image;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	@Override
	public String toString() {
		return "RegisterBean [fname=" + fname + ", lname=" + lname + ", age=" + age + ", phone=" + phone + ", mail="
				+ mail + ", password=" + password + ", address=" + address + ", type=" + type + ", city=" + city
				+ ", image=" + image + "]";
	}
	
	
}
