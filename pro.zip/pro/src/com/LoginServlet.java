package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.LoginDao;
import dao.RegisterDao;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	try{
		PrintWriter pw=response.getWriter();
		response.setContentType("text/html");

		String user=request.getParameter("uid");
		String pass=request.getParameter("pass");
		String query="select mail,password from m_p where mail=?";
		
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
		System.out.println("connection established"); 
		System.out.println(pass);
		PreparedStatement ps=conn.prepareStatement(query);
		
		ps.setString(1,user);
		ps.executeUpdate();
		ResultSet result=ps.executeQuery(query);
		if(result.next()){
		String password=result.getString("password");
		System.out.println(password);
		if(pass.equals(password)){
			pw.println("LOGIN SUCCESS");
			response.sendRedirect("Main.html");
		}
		else{
			pw.println("email/password incorrect");
			pw.println("<html><body><a href=Login.html>click here</a></body></html>");
		}
	}
	}
	
	catch(Exception e){
		e.printStackTrace();
	}
}
}

