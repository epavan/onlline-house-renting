package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DuplexServlet
 */
public class DuplexServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DuplexServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try{
			String typ="Duplex";
			String fname;
			String lname;
			String age;
			String phone;
			String mail;
			String type;
			String city;
			String address;
				Class.forName("oracle.jdbc.driver.OracleDriver");  
				Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
				System.out.println("connection established");  
				
				String query="select * from register where type_of_house=?";
				PreparedStatement ps = conn.prepareStatement(query);
				ps.setString(1, typ);
				
				ResultSet rs=ps.executeQuery();
				PrintWriter pw=response.getWriter();
				pw.println("<html><head> <meta charset=utf-8> <meta name=viewport content=width=device-width, initial-scale=1><script src=https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js>  <script src=https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js></script></script> <link rel=stylesheet href=https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css> </head><body><table style=width:100% class=table table-bordered><tr><td><strong>First_name</strong></td><td><strong>Last_Name<strong></td><td><strong>Age</strong></td><td><strong>Phone</strong></td><td><strong>mail</strong></td><td><strong>Type_Of_house</strong></td><td><strong>City</strong></td><td><strong>Address</stromg></td></tr>");
				while(rs.next()){
				 fname=rs.getString("first_name");
			     lname=rs.getString("last_name");
				 age=rs.getString("age");
				 phone=rs.getString("phone");
				 mail=rs.getString("mail");
				 type=rs.getString("type_of_house");
				 city=rs.getString("city");
				 address=rs.getString("address");
					pw.println("<tr><td>"+fname+"</td><td>"+lname+"</td><td>"+age+"</td><td>"+phone+"</td><td>"+mail+"</td><td>"+type+"</td><td>"+city+"</td><td>"+address+"</td></tr>");
				
				
				}	
				pw.println("</table></body></html>");
			}
				catch(Exception e){
					e.printStackTrace();
				}
	
	
	}

}
