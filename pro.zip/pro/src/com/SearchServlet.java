package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchServlet
 */
public class SearchServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String search=request.getParameter("search");
		

				try{
					
					String fname;
					String lname;
					String age;
					String phone;
					String mail;
					String type;
					String city;
					String address;
						Class.forName("oracle.jdbc.driver.OracleDriver");  
						Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
						System.out.println("connection established");  
						
						String query="select * from register where city=?";
						PreparedStatement ps = conn.prepareStatement(query);
						ps.setString(1, search);
						
						ResultSet rs=ps.executeQuery();
						PrintWriter pw=response.getWriter();
						pw.println("<html><body><table style=width:100%><tr><td>First_name</td><td>Last_Name</td><td>Age</td><td>Phone</td><td>mail</td><td>Type_Of_ouse</td><td>City</td><td>Address</td></tr>");
					
						while(rs.next()){
						 fname=rs.getString("first_name");
					     lname=rs.getString("last_name");
						 age=rs.getString("age");
						 phone=rs.getString("phone");
						 mail=rs.getString("mail");
						 type=rs.getString("type_of_house");
						 city=rs.getString("city");
						 address=rs.getString("address");
						 pw.println("<tr><td>"+fname+"</td><td>"+lname+"</td><td>"+age+"</td><td>"+phone+"</td><td>"+mail+"<td>type<td>"+city+"</td><td>"+address+"</td></tr>");
							
							
						}	
						pw.println("</table></body></html>");
						
					}
						catch(Exception e){
							e.printStackTrace();
						}
			}

		

	}


