package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bean.CustomerBean;
import bean.RegisterBean;

public class RegisterDao {
public static void insertOwner(RegisterBean rb){
	try{
		
	
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
	System.out.println("connection established");  
	String insert="insert into register values(?,?,?,?,?,?,?,?,?,?)";
	String mp="insert into m_p values(?,?)";
	PreparedStatement ps = conn.prepareStatement(insert);
	PreparedStatement ps1 = conn.prepareStatement(mp);
	ps.setString(1, rb.getFname());
	ps.setString(2, rb.getLname());
	ps.setString(3, rb.getAge());
	ps.setString(4, rb.getPhone());
	ps.setString(5, rb.getMail());
	ps.setString(6, rb.getPassword());
	ps.setString(7, rb.getAddress());
	ps.setString(8, rb.getType());
	ps.setString(9, rb.getCity());
	ps.setString(10, rb.getImage());
	ps1.setString(1, rb.getMail());
	ps1.setString(2, rb.getPassword());
	ps.executeUpdate();
	ps1.executeUpdate();
	
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
}
public static void insertCustomer(CustomerBean rb){
	try{
		
	
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
	System.out.println("connection established");  
	String insert="insert into customer values(?,?,?,?,?,?,?)";
	PreparedStatement ps = conn.prepareStatement(insert);
	ps.setString(1, rb.getFname());
	ps.setString(2, rb.getLname());
	ps.setString(3, rb.getAge());
	ps.setString(4, rb.getPhone());
	ps.setString(5, rb.getMail());
	ps.setString(6, rb.getPassword());
	ps.setString(7, rb.getAddress());
	
	ps.executeUpdate();
	
	
	}
	catch(Exception e){
		e.printStackTrace();
	}
	
}
}
