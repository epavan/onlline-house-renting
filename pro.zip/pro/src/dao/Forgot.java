package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class Forgot {

	public static void insert(String mobile){
		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
        System.out.println("Driver loaded successfully..");
        Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/xe","system" ,"system");
        System.out.println("Connection established successfully...");
        String insert="insert into forgot values(?,sysdate)";
        PreparedStatement ps = con.prepareStatement(insert);
        ps.setNString(1, mobile);
        ps.executeUpdate();
        
	}
		catch(Exception e){
			e.printStackTrace();
		}
}
}