package dao;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import bean.RegisterBean;

public class HouseDao {
public static void house(String typ){
	try{
		
String fname;
String lname;
String age;
String phone;
String mail;
String type;
String city;
String address;
	Class.forName("oracle.jdbc.driver.OracleDriver");  
	Connection conn= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","system");
	System.out.println("connection established");  
	
	String query="select * from register where type_of_house=?";
	PreparedStatement ps = conn.prepareStatement(query);
	ps.setString(1, typ);
	
	ResultSet rs=ps.executeQuery();
	
	while(rs.next()){
	 fname=rs.getString("first_name");
     lname=rs.getString("last_name");
	 age=rs.getString("age");
	 phone=rs.getString("phone");
	 mail=rs.getString("mail");
	 type=rs.getString("type_of_house");
	 city=rs.getString("city");
	 address=rs.getString("address");
	System.out.println(fname);
	
	}	
	
}
	catch(Exception e){
		e.printStackTrace();
	}
}

}
